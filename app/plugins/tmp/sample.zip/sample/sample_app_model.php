<?php
class SampleAppModel extends AppModel{


}