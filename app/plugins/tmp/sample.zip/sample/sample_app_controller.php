<?php
class SampleAppController extends AppController {

	function beforeFilter() {
		parent::beforeFilter();
	}
}