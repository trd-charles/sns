<?php
class Sample extends SampleAppModel {

	var $name = 'Sample';

	var $useTable = false;

}