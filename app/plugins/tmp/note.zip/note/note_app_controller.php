<?php
class NoteAppController extends AppController {

	function beforeFilter() {
		parent::beforeFilter();
	}
}