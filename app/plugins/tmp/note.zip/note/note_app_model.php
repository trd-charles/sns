<?php
class NoteAppModel extends AppModel{

}